# Software-only project audit — 23 November 2026

This is the **historical baseline audit**. Repairs and current verification are
documented in [the repair report](repair_verification.md); the original evidence
under `results/audit/` is preserved for comparison.

**Verdict: the current project has functional defects and cannot be signed off as working.**

Baseline commit: `79d9d16d472c9209b7b8bb77c7d68d55815d2960`.
This audit reviewed the tracked RTL, Python, MATLAB, embedded C/PYNQ, notebook,
dashboard, launch scripts, CI, constraints, memory fixtures, and supporting claims.
Production sources and the supplied weights/test vectors were left unchanged.
The added files are verification scripts, this report, and captured evidence.

## What was actually run

| Verification | Result |
|---|---|
| Python/RTL audit suite | **20 checks: 3 passed, 16 failed assertions, 1 runtime error, 0 skipped.** Failures are intentionally retained as defect reproductions; multiple checks can expose the same underlying defect. |
| All supplied model memory shapes and binary formats | Pass: 160 parameter files, 24,900 parameters; 1,024 sigmoid entries; 30 × 784 input words and 30 labels. |
| Python and notebook code syntax | Pass. |
| Python preprocessing, SMOTE, CNN/FCN forward and backward smoke checks | Pass. |
| Complete Python preprocessing → 10-epoch CNN → 10-epoch FCN → export → emulator | Completed in a temporary directory. CNN 98.87%, FCN 100% on the synthetic test split; exported emulator 14/30 = 46.67% on its 30-sample subset. These are different evaluation sizes, and synthetic results do not establish patient accuracy. Training initialization is unseeded, so scores can vary. |
| Emulator using the repository's original fixtures | 25/30 = **83.33%**, with five false negatives. |
| Baseline complete RTL compilation, Icarus Verilog 13.0 | **Fail:** `net_rst` declaration/use in `zynet_top.v`. |
| Temporary diagnostic top-level simulation | After moving declarations in a temporary source copy and extending the bench's AXI write-valid duration, it completed at **15/30 = 50%**, all predictions zero, with unknown first-layer data on the first inference. This is diagnostic evidence, not a successful run of the unchanged design. |
| Yosys 0.66 frontend/synthesis attempt | **Fail:** unsupported `$sformat` in `neuron.v:43`; no synthesized resource or timing result produced. |
| C driver, GCC C11 with `-Wall -Wextra -Werror -fsyntax-only` | Pass; compilation does not establish hardware data transfer. |
| JavaScript syntax, Bash syntax, PowerShell parser | Pass. |
| Dashboard mocked-DOM functional checks | 4/5 pass; saturation-error reporting fails. No browser rendering, layout or accessibility certification. |

Icarus and Yosys were extracted into a temporary tools directory from downloaded
MSYS2 packages. A normal package-install transaction failed on mirror timeouts;
it did not upgrade system packages. MATLAB, Octave, Vivado, a board, a deployment
bitstream and annotated real EEG recordings were unavailable. MATLAB findings
below are static review findings, not runtime results.

## Blocking and high-priority findings

### 1. [P1] Neuron multiplies an input by the previous weight

Locations: [neuron.v](../hardware/rtl/neuron.v), lines 56–67;
[weight_memory.v](../hardware/rtl/weight_memory.v), line 27.

The weight memory has synchronous output. On a rising edge, `prod` uses the old
`w_data`, while memory schedules the weight for the current address. The saved
`s_x_reg` is never used. `prod_valid` follows the undelayed input, so simply
changing one multiplication operand would also require realigning the valid
pipeline and end-of-vector accounting. Product pipeline registers lack reset.

Executed reproduction: weights `[1, -2, 0.5]`, inputs `[1, 0.5, 2]`, bias `0.25`
must produce Q3.13 `0x2800` (1.25). The DUT produces **`xxxx`**. The first read
starts from an uninitialized memory output; later frames can use stale weights.
The temporary complete-network diagnostic also sees `L1_FIRST=xxxx`.

Required correction: explicitly pipeline memory reads, input samples and valid
strobes together; reset/flush pipeline state; test gaps and repeated frames as
well as continuous input against an independent integer reference.

### 2. [P1] Export drops the trained Python classifier

Locations: [train_model.py](../python_pipeline/train_model.py), lines 55–62;
[export_weights.py](../python_pipeline/export_weights.py), lines 54–58;
[find_max_out.v](../hardware/rtl/find_max_out.v).

Training predicts with `out_head`, a learned 10→2 linear layer. Export includes
only `fc1`–`fc4`. RTL and emulator instead classify the largest FC4 activation,
mapping index 9 to apnea. Training never assigns that meaning to FC4 neuron 9.

Executed reproduction: a model with equal FC4 activations and a class-1 output
head bias predicts **1**; its exported network predicts **0**. This proves a
structural mismatch independently of quantization error. The complete isolated
training/export run also shows a large loss of accuracy after export.

Required correction: select one binary output architecture and class mapping,
then make training, both exporters, RTL and emulator implement it exactly.

### 3. [P1] Top level does not compile in the tested Icarus toolchain

Location: [zynet_top.v](../hardware/rtl/zynet_top.v), lines 75 and 96.

`net_rst` is used by the AHI instance before its initialized wire declaration.
Icarus 13 reports that it cannot bind `net_rst` and points to the declaration
after use. `out_done` is also implicit. Declare internal nets explicitly before
instances. The raw compiler diagnostics are retained in `evidence.json`.

### 4. [P1] AXI responses are corrupted under backpressure

Location: [axi_lite_wrapper.v](../hardware/rtl/axi_lite_wrapper.v), lines 68–91
and 114–134.

The wrapper accepts further transactions while earlier responses are pending,
without storing enough responses or preventing overwrite. Executed checks show:

- Two accepted writes with `BREADY` held low produce **one** write response.
- A read of AHI count returns `123`, then its unconsumed response changes to `2`
  when another read is issued while `RREADY=0`.

These can lose configuration operations or return the wrong register value to
the host. Gate request acceptance on response capacity and keep valid/data
stable until the response is consumed. The exposed interface also has no WSTRB,
so byte-write support is absent from the advertised AXI4-Lite integration.

### 5. [P1] The supplied top-level bench misses the control-write handshake

Location: [tb_top_sim.v](../hardware/tb/tb_top_sim.v), `send_data`, lines 90–110.

AWVALID and WVALID are asserted for one cycle, then withdrawn when the wrapper
has only just raised READY. The DUT commits the write on the following edge,
when WVALID has already gone low. After the compilation defect is bypassed,
this prevents the start operation from completing. The bench waits indefinitely
and has no watchdog or failure assertion. A separate temporary bench with only
the declaration workaround and a 2,000-clock watchdog fails without completing
the first inference. The temporary diagnostic holds valid
longer solely to inspect downstream behavior; production files are unchanged.

Use clocked handshake tasks that hold address/data/valid through acceptance,
check responses, enforce a timeout, and fail on unknown arithmetic values.

### 6. [P1] PYNQ inference never transfers the input and can report stale results

Location: [neurosomno_overlay.py](../embedded/pynq/neurosomno_overlay.py),
lines 38–40 and 61–77.

`predict_sample` checks the array length but never uses its values. There is no
DMA allocation or transfer. It writes START, polls registers, and returns an
output even if the poll exhausts its iterations. The fallback starts with DONE
already set and NNOUT zero; it is a register stub, not an inference simulation.

Executed reproductions: supplied sample 1 should be class 1 in the emulator but
returns 0 from the fallback; a permanently unfinished device returns normally
instead of raising `TimeoutError`. Broad exception handling also turns overlay
loading/configuration errors into apparent software-mode success.

Implement a real streaming transport and explicit emulator mode, clear/observe
completion correctly, and propagate initialization and timeout failures.
The embedded README calls nonexistent `infer_sample`; the class defines
`predict_sample`. The C API compiles but likewise provides control/status helpers
without a sample-streaming implementation.

### 7. [P1] Hardware filters do not implement the stated filtering behavior

Locations: [iir_notch_50hz.v](../hardware/rtl/iir_notch_50hz.v), coefficient
definitions; [iir_bandpass.v](../hardware/rtl/iir_bandpass.v).

The implemented notch recurrence has poles approximately **1.77007** and
**−0.51702**, using its actual Q3.13 denominator coefficients. A pole outside the
unit circle makes this linear recurrence unstable. Output clamping does not
repair the coefficients; state feedback uses the sliced unsaturated output.

The bandpass contains only one biquad, with no upper-cutoff lowpass section.
Its coefficient response has gain **1.0003 at 60 Hz**, versus **1.0972 at 10 Hz**;
it does not reject frequencies above 45 Hz as described.

Neither filter, convolution nor pooling is instantiated in `zynet_top`. The
deployed top is an FCN receiving already prepared 784-element vectors, not a
raw-EEG CNN/preprocessing pipeline. Redesign and verify coefficients, internal
numeric ranges, sample rate and the intended integration path.

### 8. [P1] Real EDF data receives fabricated all-normal labels; splits leak overlapping windows

Location: [preprocess_eeg.py](../python_pipeline/preprocess_eeg.py), lines
118 and 135–146; [segment_eeg.m](../matlab_preprocessing/segment_eeg.m).

The Python EDF branch unconditionally creates all-zero labels rather than
loading apnea annotations. MATLAB also substitutes zeros when annotation files
are missing. A real recording can therefore silently become an all-normal
training/test dataset. Missing C3/C4 channel names also silently select unrelated
channels in Python.

Both pipelines split after creating 11-second windows at one-second intervals.
Adjacent windows share 10 seconds of raw signal, yet can enter different splits;
patients are mixed across splits too. Reported test scores therefore do not
establish accuracy on unseen patients. Require real annotations and channels,
split by patient before segmentation, and preserve data/subject provenance.

### 9. [P1] MATLAB FCN output size disagrees with binary labels

Location: [train_1dcnn.m](../matlab_preprocessing/train_1dcnn.m), lines 56–68.

The FCN ends with 10 outputs and a classification layer, while targets contain
two categorical classes. This is a static output/target dimension mismatch and
is expected to reject training. Changing only that size would also require
updating the four-layer export, RTL, emulator and class mapping. MATLAB execution
was unavailable, so no MATLAB runtime error is claimed here.

### 10. [P1] Current tools do not establish the published synthesis/accuracy claims

Locations: [bit_true_emulator.py](../python_pipeline/bit_true_emulator.py),
line 136; [.github/workflows/rtl_ci.yml](../.github/workflows/rtl_ci.yml);
[neuron.v](../hardware/rtl/neuron.v), line 43;
[weight_memory.v](../hardware/rtl/weight_memory.v), line 21.

The emulator unconditionally prints perfect RTL parity without invoking a
simulator or comparing any RTL outputs. It models arithmetic, not cycle timing,
and cannot reproduce the stale-weight/unknown-state defect. The CI accepts the
presence of the string `Overall Accuracy`; it does not enforce its commented
accuracy threshold or numerical parity. Unit benches lack expected-value checks.

The supplied fixtures score **83.33%** in the emulator, contrary to the stated
86.67–90% subset range. `verify_quantization.py` checks file formatting/ranges,
not loss against original floating-point parameters or inference parity.

The tested Yosys frontend rejects procedural `$sformat` filename generation.
The Windows tool also required explicit source filenames instead of the
documented wildcard. No raw Vivado implementation/timing/power reports or
reproducible implementation scripts are included. The written estimates cannot
certify timing closure, board fit, or power for these sources. A routed Vivado
build and reports are needed for those claims; no physical board is required
for that part, but the vendor toolchain is required.

## Additional functional defects

- **[P2] Convolution loses the final valid window.** `conv1d_pe.v:72` multiplies
  the previous window but gates it with the current `i_valid`. With K=2 and
  samples `[100,200,300]`, it emits only `300`, omitting `500`. Delay window-valid
  with the window and flush the final pending output independently of new input.
- **[P2] Pooling parameters do not work as advertised.** `maxpool1d.v` declares
  `STRIDE` but never uses it. K=2, stride=1 over three samples emits one output
  instead of two. `POOL_SIZE=1` also cannot take the output branch correctly.
- **[P2] AHI tracker counts inference strobes as seconds.** There is no elapsed
  time input/divider or hourly normalization; severity compares a lifetime event
  count directly against thresholds. The 10-second event appears at the 11th
  positive strobe: the executed ten-strobe test reports zero events. Duration is
  an 8-bit wrapping counter; severity uses the old count. `ahi_alarm_intr` is
  unconnected to the top-level interrupt/status path. These are implementation
  and labeling problems, not validated clinical telemetry.
- **[P2] Soft reset leaves `running` and completion bookkeeping inconsistent.**
  `zynet_top.v:83` resets `running` only on external `rst`, while the datapath is
  reset by `soft_rst`. `s_axis_tready` can remain high during software reset.
  It remains high after the 784th input while downstream inference executes,
  and TLAST is ignored. Extra/malformed frames are not safely rejected.
- **[P2] MATLAB real-data/edge cases need correction.** EDF timetable extraction
  assumes direct numeric conversion rather than handling stored channel records;
  column vectors in `segment_eeg.m:25` produce a 1408×2 segment instead of one
  2816-element row. The MATLAB path assumes 128 Hz without resampling, unlike
  Python. `normalize_zscore.m` divides by zero for constant windows. SMOTE calls
  `randi` with invalid bounds for zero/one minority examples. Synthetic MATLAB
  preprocessing bypasses the filters, and MATLAB uses causal filtering while
  Python uses zero-phase filtering. These paths are not interchangeable.
- **[P2] Small test exports crash.** `export_weights.py` loops over the requested
  30 samples even if fewer test samples exist. The two-sample reproduction raises
  `IndexError` after partially writing output. Clamp/validate counts before writes.
- **[P2] Emulator accepts incomplete vectors.** `BitTrueNeuron.compute` uses
  `zip`, silently truncating mismatched lengths. A one-element input can produce
  a classification instead of rejecting a malformed 784-element frame.
- **[P2] Launch scripts can hide failures.** PowerShell/CMD do not consistently
  check each native exit code before announcing success. Vivado launchers do not
  provision the relative memory-file simulation paths. Octave is offered as a
  drop-in training route despite calls to MATLAB-specific deep learning and
  fixed-point APIs; that route was not executable in this environment. CMD also
  expands `%ERRORLEVEL%` inside nested blocks before the nested `where` commands.
- **[P2] Dashboard values are illustrative.** Classification is scheduled by
  synthetic time intervals; activation bars are random; the confusion matrix is
  calculated from hardcoded curves. These are not outputs from the trained
  model, RTL or a board. Simulation advances a fixed 1/60 second per rendered
  frame, so wall-clock speed depends on display/frame rate. The Q3.13 calculator
  clips its input before computing error: input 6 reconstructs as 3.999878 but
  displays error **0.000000**, omitting saturation loss (executed reproduction).

## Reproduction and evidence

From the repository root, with the Python requirements installed:

```powershell
python tests/audit_project.py --iverilog <iverilog.exe> --vvp <vvp.exe>
node tests/audit_dashboard.cjs
python -u tests/audit_training.py
```

The first two commands intentionally return nonzero while their defect
reproductions fail. Missing Icarus tools are recorded as skipped tests. The full
training command creates and removes an isolated working directory so it does
not overwrite the supplied fixtures. It can finish successfully despite the
project's export defect; compare its printed results.

Artifacts:

- [Machine-readable evidence](../results/audit/evidence.json)
- [Python/RTL audit output](../results/audit/test_run.txt)
- [Isolated full training/export output](../results/audit/training_run.txt)
- [Yosys output](../results/audit/synthesis_run.txt)
- [Dashboard check output](../results/audit/dashboard_run.txt)

## What remains unverified

Software simulation has already demonstrated errors; physical testing is not
needed to establish these findings. Correctness after repairs still needs
RTL/emulator equality over complete layer outputs, repeated and stalled frames,
AXI protocol/backpressure/reset regressions, valid real-data labels and patient
splits, and a vendor synthesis/place-and-route run. Board electrical behavior,
real DMA/interrupt delivery, sensor acquisition and measured power cannot be
certified by this audit. The project has not been established as a functioning
sleep-apnea detector on real patient data.
